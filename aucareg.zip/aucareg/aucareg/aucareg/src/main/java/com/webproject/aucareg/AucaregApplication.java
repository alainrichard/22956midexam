package com.webproject.aucareg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AucaregApplication {

	public static void main(String[] args) {
		SpringApplication.run(AucaregApplication.class, args);
	}

}
