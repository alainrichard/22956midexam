package com.webproject.aucareg.controller;

import com.webproject.aucareg.dto.AcademicUnitDto;
import com.webproject.aucareg.model.AcademicUnit;
import com.webproject.aucareg.service.AcademicUnitService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

@Controller
public class AcademicUnitController {
    private AcademicUnitService academicUnitService;
    @Autowired
    public AcademicUnitController(AcademicUnitService academicUnitService) {
        this.academicUnitService = academicUnitService;
    }

    @GetMapping("/academic_unit")
    public String createAcademicForm(Model model){
        AcademicUnit academicUnit= new AcademicUnit();
        List<AcademicUnitDto> academicUnits = academicUnitService.findAllAcademicUbits();
        model.addAttribute("academicUnits", academicUnits);
        model.addAttribute("academicUnit",academicUnit);
        return "academic_unit";
    }

    @PostMapping("/academic_unit/new")
    public String saveAcademicUnit(@ModelAttribute("academicUnit") AcademicUnit academicUnit){
        academicUnitService.saveAcademicUnit(academicUnit);
        return "redirect:/academic_unit";
    }
}
