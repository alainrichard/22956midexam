package com.webproject.aucareg.controller;

public @interface Controller {
}
