package com.webproject.aucareg.controller;

import com.webproject.aucareg.dto.CourseDto;
import com.webproject.aucareg.model.Course;
import com.webproject.aucareg.service.CourseService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

@Controller
public class CourseController {
    private CourseService courseService;

    public CourseController(CourseService courseService) {
        this.courseService = courseService;
    }

    @GetMapping("/course")
    public String createCourse (Model model){
        Course course = new Course();
        List<CourseDto> courseDtos = courseService.findAllCourses();
        model.addAttribute("courseDtos",courseDtos);
        model.addAttribute("course",course);
        return "course";
    }

    @PostMapping("/course/new")
    public  String saveCourse(@ModelAttribute("course") Course course){
        courseService.saveCourse(course);
        return "redirect:/course";
    }
}

