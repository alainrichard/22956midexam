package com.webproject.aucareg.controller;

import com.webproject.aucareg.dto.CourseDefinitionDto;
import com.webproject.aucareg.model.CourseDefinition;
import com.webproject.aucareg.service.CourseDefinitionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

@Controller
public class CourseDefinitionController {
    private CourseDefinitionService courseDefinitionService;

    @Autowired

    public CourseDefinitionController(CourseDefinitionService courseDefinitionService) {
        this.courseDefinitionService = courseDefinitionService;
    }

    @GetMapping("/course_definition")
    public String createCourseDefinition(Model model){
        CourseDefinition courseDefinition = new CourseDefinition();
        List<CourseDefinitionDto> courseDefinitionDtoList = courseDefinitionService.findAllCourseDefinition();
        model.addAttribute("courseDefinitionDtoList",courseDefinitionDtoList);
        model.addAttribute("courseDefinition",courseDefinition);
        return "course_definition";
    }

    @PostMapping("/course_definition/new")
    public String saveCourseDefinition(@ModelAttribute("courseDefinition") CourseDefinition courseDefinition){
        courseDefinitionService.saveCourseDefinition(courseDefinition);
        return  "redirect:/course_definition";
    }

}
