package com.webproject.aucareg.controller;

import com.webproject.aucareg.dto.SemesterDto;
import com.webproject.aucareg.model.Semester;
import com.webproject.aucareg.service.SemesterService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

@Controller
public class SemesterController {
    private SemesterService semesterService;

    public SemesterController(SemesterService semesterService) {
        this.semesterService = semesterService;
    }

    @GetMapping("/semester")
    public String createSemesterForm(Model model){//Model model biva kuri backend bijya kuri Front End
        Semester semester = new Semester();
        List<SemesterDto> semesterDtos = semesterService.findAllSemesters();
        model.addAttribute("semesterDtos",semesterDtos);
        model.addAttribute("semester",semester);
        return "semester";
    }

    @PostMapping("/semester/new")
    public String saveTeacher(@ModelAttribute("semester") Semester semester){
        semesterService.saveSemester(semester);
        return "redirect:/semester";
    }
}
