package com.webproject.aucareg.controller;

import com.webproject.aucareg.dto.StudentDto;
import com.webproject.aucareg.model.Student;
import com.webproject.aucareg.service.StudentService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;
import java.util.Random;

@Controller
public class StudentController {
    private StudentService studentService;

    public StudentController(StudentService studentService) {
        this.studentService = studentService;
    }

    @GetMapping("/student")
    public  String createStudentForm(Model model){
        Student stud = new Student();
        List<StudentDto> studentDtos=studentService.findAllStudents();

        int min = 1000; // Define your minimum registration number
        int max = 9999; // Define your maximum registration number
        int randomRegistrationNumber = new Random().nextInt(max - min + 1) + min;

        model.addAttribute("randomRegistrationNumber", "AUCA-REG-" + randomRegistrationNumber);
        model.addAttribute("studentDtos",studentDtos);
        model.addAttribute("student",stud);
        return "student";

    }

    @PostMapping("/student/new")
    public String saveStudent(@ModelAttribute("student") Student student){
        studentService.saveStudent(student);
        return "redirect:/student";
    }


}
