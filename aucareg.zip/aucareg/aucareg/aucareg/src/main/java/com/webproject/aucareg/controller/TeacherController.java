package com.webproject.aucareg.controller;

import com.webproject.aucareg.dto.TeacherDto;
import com.webproject.aucareg.model.Teacher;
import com.webproject.aucareg.service.TeacherService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

@Controller
public class TeacherController {

    private TeacherService teacherService;

    public TeacherController(TeacherService teacherService) {
        this.teacherService = teacherService;
    }

    @GetMapping("/teacher")
    public String createTeacherForm(Model model){
        Teacher teacher = new Teacher();
        List<TeacherDto> teacherListDtos = teacherService.findAllTeachers();
        model.addAttribute("teacherListDtos",teacherListDtos);
        model.addAttribute("teacher",teacher);
        return "teacher";
    }

    @PostMapping("/teacher/new")
    public String saveTeacher(@ModelAttribute("teacher") Teacher teacher){
        teacherService.saveTeacher(teacher);
        return "redirect:/teacher";

    }
}

