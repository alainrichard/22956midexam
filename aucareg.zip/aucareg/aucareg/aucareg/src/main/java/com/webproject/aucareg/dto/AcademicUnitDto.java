package com.webproject.aucareg.dto;

import com.webproject.aucareg.model.AcademicUnit;
import com.webproject.aucareg.model.Course;
import com.webproject.aucareg.model.enums.EAccademicUnit;
import jakarta.persistence.*;
import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class AcademicUnitDto {
    private String code;
    private String name;
    private EAccademicUnit unit;
    private AcademicUnit parent;

    @OneToMany(mappedBy = "academicUnit")
    private List<Course> courses;
}
