package com.webproject.aucareg.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CourseDefinitionDto {//we use Dtos to return specific Information... a Dto can provide security and convinience
    private String codeDef;
    private String name;
    private String description;
//    @OneToMany(mappedBy = "courseDefinition")
//    private List<Cource> courses;
}
