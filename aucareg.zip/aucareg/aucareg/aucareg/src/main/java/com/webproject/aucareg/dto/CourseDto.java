package com.webproject.aucareg.dto;

import com.webproject.aucareg.model.AcademicUnit;
import com.webproject.aucareg.model.CourseDefinition;
import com.webproject.aucareg.model.Semester;
import com.webproject.aucareg.model.Teacher;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.Builder;
import lombok.Data;

/**
 *
 */
@Data
@Builder
public class CourseDto {
    private String courseCode;
    private Integer credit;

    private CourseDefinition courseDefinition;

    private Teacher treTeacher;

    private Semester semester;

    private AcademicUnit academicUnit;
}
