package com.webproject.aucareg.dto;

import lombok.Builder;
import lombok.Data;

import java.time.LocalDate;
@Data
@Builder
public class SemesterDto {
    private String semId;
    private String name;

    private LocalDate startDate;
    private LocalDate endDate;
}
