package com.webproject.aucareg.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class StudentDto {

    private String regNo;
    private String fName;
    private String lName;
    private String dateOfBirth;
//    @OneToOne(mappedBy = "student")
//    private StudentRegistration studentRegistration;
}
