package com.webproject.aucareg.dto;

import com.webproject.aucareg.model.enums.EQualification;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class TeacherDto {
    private String tCode;
    private String name;
    private String email;
    private String phone;
    private String teacherType;

    private EQualification qualification;
}
