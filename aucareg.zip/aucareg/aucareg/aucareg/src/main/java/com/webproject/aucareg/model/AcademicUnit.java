package com.webproject.aucareg.model;

import com.webproject.aucareg.model.enums.EAccademicUnit;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name="academic_unit")
public class AcademicUnit {
    @Id
    @Column(name = "code")
    private String code;
    @Column(name = "academicName")
    private String name;
    @Column(name = "Unit")
    @Enumerated(EnumType.STRING)
    private EAccademicUnit unit;

    @ManyToOne(cascade = CascadeType.REMOVE)
    @JoinColumn(name = "parent_id",nullable = true)
    private AcademicUnit parent;
//    @OneToMany(mappedBy = "academicUnit")
//    private List<StudentRegistration> studentRegistration;
    @OneToMany(mappedBy = "academicUnit")
    private List<Course> courses;
}
