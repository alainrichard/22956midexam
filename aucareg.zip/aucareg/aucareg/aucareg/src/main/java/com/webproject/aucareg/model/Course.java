package com.webproject.aucareg.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name="course")
public class Course {
    @Id
    private String courseCode;
    private Integer credit;
    @ManyToOne
    @JoinColumn( name = "codeDef")
    private CourseDefinition courseDefinition;
    @ManyToOne
    @JoinColumn(name = "tId")
    private Teacher treTeacher;
    @ManyToOne
    @JoinColumn(name = "sId")
    private Semester semester;
    @ManyToOne
    @JoinColumn(name = "code")
    private AcademicUnit academicUnit;

}
