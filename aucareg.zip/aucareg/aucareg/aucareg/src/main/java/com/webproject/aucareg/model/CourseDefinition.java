package com.webproject.aucareg.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name="course_definition")
public class CourseDefinition {
    @Id
    private String codeDef;
    private String name;
    private String description;
//    @OneToMany(mappedBy = "courseDefinition")
//    private List<Course> courses;
}
