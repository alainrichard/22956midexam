package com.webproject.aucareg.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.List;
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name="semester")
public class Semester {
    @Id
    private String semId;
    private String name;

    private LocalDate startDate;
    private LocalDate endDate;
    @OneToMany(mappedBy = "semester")
    private List<Course> courses;
//    @OneToMany(mappedBy = "studentId")
//    private List<StudentRegistration> studentRegistrations;
}
