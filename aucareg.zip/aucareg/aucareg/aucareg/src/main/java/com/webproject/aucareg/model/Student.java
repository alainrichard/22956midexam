package com.webproject.aucareg.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
//@NoArgsConstructor
//@AllArgsConstructor
@Builder
@Entity
@Table(name="student")
public class Student {
    @Id
    private String regNo;
    private String fName;
    private String lName;
    private String dateOfBirth;
//    @OneToOne(mappedBy = "student")
//    private StudentRegistration studentRegistration;

    public Student() {
    }

    public Student(String regNo, String fName, String lName, String dateOfBirth) {
        this.regNo = regNo;
        this.fName = fName;
        this.lName = lName;
        this.dateOfBirth = dateOfBirth;
    }

    public String getRegNo() {
        return regNo;
    }

    public void setRegNo(String regNo) {
        this.regNo = regNo;
    }

    public String getfName() {
        return fName;
    }

    public void setfName(String fName) {
        this.fName = fName;
    }

    public String getlName() {
        return lName;
    }

    public void setlName(String lName) {
        this.lName = lName;
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }
}
