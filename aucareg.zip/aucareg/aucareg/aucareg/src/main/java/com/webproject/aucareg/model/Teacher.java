package com.webproject.aucareg.model;

import com.webproject.aucareg.model.enums.EQualification;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name="teacher")
public class Teacher {
    @Id
    private String tCode;
    private String name;
    private String email;
    private String phone;
    private String teacherType;
    @Enumerated(EnumType.STRING)
    @Column(name = "qualification")
    private EQualification qualification;
    @OneToMany(mappedBy = "treTeacher")
    private List<Course> courses;
}
