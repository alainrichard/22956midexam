package com.webproject.aucareg.model.enums;

public enum EAccademicUnit {
    PROGRAMME,
    FACULTY,
    DEPARTMENT;
}
