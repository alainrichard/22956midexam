package com.webproject.aucareg.model.enums;

public enum EQualification {
    MASTERS,
    PHD,
    PROFESSOR;
}
