package com.webproject.aucareg.repository;

import com.webproject.aucareg.model.AcademicUnit;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Academic_repository extends JpaRepository<AcademicUnit,String> {
}
