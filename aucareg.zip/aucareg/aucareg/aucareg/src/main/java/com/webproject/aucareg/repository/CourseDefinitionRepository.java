package com.webproject.aucareg.repository;

import com.webproject.aucareg.model.CourseDefinition;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CourseDefinitionRepository extends JpaRepository<CourseDefinition,String> {
}
