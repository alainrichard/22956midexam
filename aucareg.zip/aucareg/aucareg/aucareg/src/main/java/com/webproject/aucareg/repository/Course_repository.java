package com.webproject.aucareg.repository;

import com.webproject.aucareg.model.Course;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Course_repository extends JpaRepository<Course,String> {
}
