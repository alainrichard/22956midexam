package com.webproject.aucareg.repository;

import com.webproject.aucareg.model.Semester;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Semester_repository extends JpaRepository<Semester,String> {
}
