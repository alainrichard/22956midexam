package com.webproject.aucareg.repository;

import com.webproject.aucareg.model.Student;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Student_repository extends JpaRepository<Student,String> {
}
