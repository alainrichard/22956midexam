package com.webproject.aucareg.service;

import com.webproject.aucareg.dto.AcademicUnitDto;
import com.webproject.aucareg.model.AcademicUnit;

import java.util.List;

public interface AcademicUnitService {
    List<AcademicUnitDto> findAllAcademicUbits();
    AcademicUnit saveAcademicUnit(AcademicUnit academicUnit);
}
