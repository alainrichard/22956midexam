package com.webproject.aucareg.service;

import com.webproject.aucareg.dto.CourseDefinitionDto;
import com.webproject.aucareg.model.CourseDefinition;

import java.util.List;

public interface CourseDefinitionService {
    List<CourseDefinitionDto> findAllCourseDefinition();
    CourseDefinition saveCourseDefinition(CourseDefinition courseDefinition);
}
