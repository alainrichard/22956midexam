package com.webproject.aucareg.service;

import com.webproject.aucareg.dto.CourseDto;
import com.webproject.aucareg.model.Course;
import com.webproject.aucareg.model.Semester;

import java.util.List;

public interface CourseService {
    List<CourseDto> findAllCourses();
    Course saveCourse(Course course);
}
