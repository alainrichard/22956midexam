package com.webproject.aucareg.service;

import com.webproject.aucareg.dto.SemesterDto;
import com.webproject.aucareg.model.Semester;

import java.util.List;

public interface SemesterService {
    List<SemesterDto> findAllSemesters();
    Semester saveSemester(Semester semester);
}
