package com.webproject.aucareg.service;

import com.webproject.aucareg.dto.StudentDto;
import com.webproject.aucareg.model.Student;

import java.util.List;

public interface StudentService {
    List<StudentDto> findAllStudents();
    Student saveStudent(Student student);
}
