package com.webproject.aucareg.service;

import com.webproject.aucareg.dto.TeacherDto;
import com.webproject.aucareg.model.Teacher;

import java.util.List;

public interface TeacherService {
    List<TeacherDto> findAllTeachers();

    Teacher saveTeacher(Teacher teacher);
}
