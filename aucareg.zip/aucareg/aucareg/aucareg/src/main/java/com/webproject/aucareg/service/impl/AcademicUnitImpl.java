package com.webproject.aucareg.service.impl;

import com.webproject.aucareg.dto.AcademicUnitDto;
import com.webproject.aucareg.model.AcademicUnit;
import com.webproject.aucareg.repository.Academic_repository;
import com.webproject.aucareg.service.AcademicUnitService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class AcademicUnitImpl implements AcademicUnitService {
    private Academic_repository academic_repository;

    @Autowired

    public AcademicUnitImpl(Academic_repository academicRepository) {
        academic_repository = academicRepository;
    }

    @Override
    public List<AcademicUnitDto> findAllAcademicUbits() {
        List<AcademicUnit> academicUnits=academic_repository.findAll();
        return academicUnits.stream().map((academicUnit) -> mapToAcademicUnitDto(academicUnit)).collect(Collectors.toList());
    }

    private AcademicUnitDto mapToAcademicUnitDto(AcademicUnit academicUnit) {
        AcademicUnitDto academicUnitDto = AcademicUnitDto.builder()
                .code(academicUnit.getCode())
                .name(academicUnit.getName())
                .unit(academicUnit.getUnit())
                .parent(academicUnit.getParent())
                .build();
        return academicUnitDto;
    }

    @Override

    public AcademicUnit saveAcademicUnit(AcademicUnit academicUnit) {

        return academic_repository.save(academicUnit);
    }
}
