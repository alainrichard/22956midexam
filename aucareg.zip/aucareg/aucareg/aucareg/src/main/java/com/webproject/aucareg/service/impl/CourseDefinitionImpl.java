package com.webproject.aucareg.service.impl;

import com.webproject.aucareg.dto.CourseDefinitionDto;
import com.webproject.aucareg.model.CourseDefinition;
import com.webproject.aucareg.repository.CourseDefinitionRepository;
import com.webproject.aucareg.service.CourseDefinitionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;
@Service
public class CourseDefinitionImpl implements CourseDefinitionService {
    private CourseDefinitionRepository courseDefinitionRepository;
    @Autowired
    public CourseDefinitionImpl(CourseDefinitionRepository courseDefinitionRepository) {
        this.courseDefinitionRepository = courseDefinitionRepository;
    }

    @Override
    public List<CourseDefinitionDto> findAllCourseDefinition() {
        List<CourseDefinition> courseDefinitions =courseDefinitionRepository.findAll();
        return courseDefinitions.stream().map((courseDefinition) -> mapToCourseDefinitionDto(courseDefinition)).collect(Collectors.toList());
    }

    @Override
    public CourseDefinition saveCourseDefinition(CourseDefinition courseDefinition) {
        return courseDefinitionRepository.save(courseDefinition);
    }

    private CourseDefinitionDto mapToCourseDefinitionDto(CourseDefinition courseDefinition){
        CourseDefinitionDto courseDefinitionDto= CourseDefinitionDto.builder()
                .codeDef(courseDefinition.getCodeDef())
                .name(courseDefinition.getName())
                .description(courseDefinition.getDescription())
                .build();
        return  courseDefinitionDto;

    }
}
