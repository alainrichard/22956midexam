package com.webproject.aucareg.service.impl;

import com.webproject.aucareg.dto.CourseDto;
import com.webproject.aucareg.model.Course;
import com.webproject.aucareg.repository.Course_repository;
import com.webproject.aucareg.service.CourseService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class CourseImpl implements CourseService {

    private Course_repository courseRepository;

    public CourseImpl(Course_repository courseRepository) {
        this.courseRepository = courseRepository;
    }

    @Override
    public List<CourseDto> findAllCourses() {
        List<Course> courses = courseRepository.findAll();
        return courses.stream().map((course) -> mapToCourseDefinitionDto(course)).collect(Collectors.toList());
    }

    @Override ///verify this .getSemester()
    public Course saveCourse(Course course) {

        return courseRepository.save(course);
    }
    private CourseDto mapToCourseDefinitionDto(Course course){
        CourseDto courseDto = CourseDto.builder()
                .courseCode(course.getCourseCode())
                .credit(course.getCredit())
                .courseDefinition(course.getCourseDefinition())
                .treTeacher(course.getTreTeacher())
                .semester(course.getSemester())
                .academicUnit(course.getAcademicUnit())
                .build();
        return courseDto;

    }
}
