package com.webproject.aucareg.service.impl;

import com.webproject.aucareg.dto.SemesterDto;
import com.webproject.aucareg.model.Semester;
import com.webproject.aucareg.repository.Semester_repository;
import com.webproject.aucareg.service.SemesterService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class SemesterImpl implements SemesterService {
   private Semester_repository semesterRepository;

    public SemesterImpl(Semester_repository semesterRepository) {
        this.semesterRepository = semesterRepository;
    }

    @Override
    public List<SemesterDto> findAllSemesters() {
        List<Semester> semesters = semesterRepository.findAll();
        return semesters.stream().map((semester) -> mapToSemesterDto(semester)).collect(Collectors.toList());

    }

    @Override
    public Semester saveSemester(Semester semester) {
        return semesterRepository.save(semester);
    }

    private SemesterDto mapToSemesterDto (Semester semester){
        SemesterDto semesterDto= SemesterDto.builder()
                .semId(semester.getSemId())
                .name(semester.getName())
                .startDate(semester.getStartDate())
                .endDate(semester.getEndDate())
                .build();
        return semesterDto;
    }


}
