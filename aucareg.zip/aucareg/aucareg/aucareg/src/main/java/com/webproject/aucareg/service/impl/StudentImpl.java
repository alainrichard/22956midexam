package com.webproject.aucareg.service.impl;

import com.webproject.aucareg.dto.StudentDto;
import com.webproject.aucareg.model.Student;
import com.webproject.aucareg.repository.Student_repository;
import com.webproject.aucareg.service.StudentService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class StudentImpl implements StudentService {

    private Student_repository studentRepository;

    public StudentImpl(Student_repository studentRepository) {
        this.studentRepository = studentRepository;
    }

    @Override
    public List<StudentDto> findAllStudents() {
        List<Student> students = studentRepository.findAll();
        return students.stream().map((student) -> mapToStudentDto(student)).collect(Collectors.toList()) ;
    }

    @Override
    public Student saveStudent(Student student) {
        return null;
    }

   private StudentDto mapToStudentDto(Student student){
        StudentDto studentDto = StudentDto.builder()
                .regNo(student.getRegNo())
                .fName(student.getfName())
                .lName(student.getlName())
                .dateOfBirth(student.getDateOfBirth())
                .build();
        return studentDto;
   }
}
