package com.webproject.aucareg.service.impl;

import com.webproject.aucareg.dto.TeacherDto;
import com.webproject.aucareg.model.Teacher;
import com.webproject.aucareg.repository.Teacher_repository;
import com.webproject.aucareg.service.TeacherService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;
@Service
public class TeacherImpl implements TeacherService {

    private Teacher_repository teacherRepository;

    public TeacherImpl(Teacher_repository teacherRepository) {
        this.teacherRepository = teacherRepository;
    }

    @Override
    public List<TeacherDto> findAllTeachers() {
        List<Teacher> teachers = teacherRepository.findAll();
        return teachers.stream().map((teacher) -> mapToTeacherDto(teacher)).collect(Collectors.toList());

    }

    private TeacherDto mapToTeacherDto(Teacher teacher){
        TeacherDto teacherDto = TeacherDto.builder()
                .tCode(teacher.getTCode())
                .name(teacher.getName())
                .email(teacher.getEmail())
                .phone(teacher.getPhone())
                .teacherType(teacher.getTeacherType())
                .qualification(teacher.getQualification())
                .phone(teacher.getPhone())
                .build();
        return teacherDto;
    }

    @Override
    public Teacher saveTeacher(Teacher teacher) {

        return teacherRepository.save(teacher);
    }
}
