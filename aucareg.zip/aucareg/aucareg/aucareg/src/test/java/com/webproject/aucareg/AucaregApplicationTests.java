package com.webproject.aucareg;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AucaregApplicationTests {

	@Test
	void contextLoads() {
	}

}
